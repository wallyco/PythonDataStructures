def main():
    #Log in function
        #returns Student
    #Call Menu(with returned student)
    pass

if __name__ == "__main__":
    main()
