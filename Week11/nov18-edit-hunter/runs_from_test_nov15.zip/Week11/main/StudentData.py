class StudentData:

    def __init__(self, id=None, course=None):

        self.course = course if course is not None else set([])
        self.data = {
            "StudentId" : id,
            "StudentCourse" : self.course
        }

    def add(self, course):
        if course not in self.data.get("StudentCourse"):
            self.data.get("StudentCourse").add(course)
            print(f"Course '{course}' added.")
        else:
            print(f"Course '{course}' already registered.")
        pass

    def remove(self, course):
        if course in self.data.get("StudentCourse"):
            self.data.get("StudentCourse").remove(course)
            print(f"Course '{course}' dropped.")
        else:
            print(f"Course '{course}' not found in registered courses.")

        pass

    def coursesToString(self):
        return print(self.data["StudentCourse"])
