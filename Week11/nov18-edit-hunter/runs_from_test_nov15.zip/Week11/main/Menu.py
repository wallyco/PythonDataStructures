from main.Student import Student

def menu(student):

    userinput = str(input(""""Enter '1' to Add a course|
       '2' to Drop a course|
       '3' to View your courses|
       '4' to exit |
        """))
    if userinput == "1":
        courseinput = str(input("Enter coursename to add: "))
        student.addCourse(courseinput)
        menu(student)
    elif userinput == "2":
        courseinput = str(input("Enter coursename to drop: "))
        student.removeCourse(courseinput)
        menu(student)
    elif userinput == "3":
        student.showCourses()
        menu(student)
    elif userinput == "4":
        print("Exiting to login")
    else:
        print("That option is invalid")
        menu(student)

