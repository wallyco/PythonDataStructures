from main.Menu import menu
from main.Login import login, register
from main.Student import Student


def main():

    menu(login())


if __name__ == "__main__":
    main()
